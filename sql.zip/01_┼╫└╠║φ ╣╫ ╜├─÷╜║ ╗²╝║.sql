CREATE TABLE jmuser(
    jmuser_idx NUMBER PRIMARY KEY,
    jmuser_id VARCHAR2(20) UNIQUE NOT NULL,
    jmuser_pw VARCHAR2(50) NOT NULL,
    jmuser_name VARCHAR2(20) NOT NULL,
    jmuser_nickname VARCHAR2(20),
    jmuser_birth VARCHAR2(20),
    jmuser_gender VARCHAR2(5),
    jmuser_tel VARCHAR2(30),
    jmuser_email VARCHAR2(50),
    jmuser_addr VARCHAR2(100),
    jmuser_favorite CLOB
);

CREATE TABLE song(
    song_number NUMBER PRIMARY KEY,
    song_name VARCHAR2(100) NOT NULL,
    singer VARCHAR2(50) NOT NULL,
    album_name VARCHAR2(100) NOT NULL,
    link CLOB,
    playcount NUMBER DEFAULT 0
);

CREATE TABLE singer(
    signer_number NUMBER PRIMARY KEY,
    singer VARCHAR2(50) NOT NULL,
    debut_date DATE,
    company VARCHAR2(50)
);

CREATE TABLE album(
    album_number NUMBER PRIMARY KEY,
    album_name VARCHAR2(100) NOT NULL,
    singer VARCHAR2(50) NOT NULL,
    release_date DATE
);

CREATE SEQUENCE jmuser_seq;
CREATE SEQUENCE song_seq;
CREATE SEQUENCE singer_seq;
CREATE SEQUENCE album_seq;