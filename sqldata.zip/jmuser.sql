CREATE TABLE jmuser(
    jmuser_idx NUMBER PRIMARY KEY,
    jmuser_id VARCHAR2(20) UNIQUE NOT NULL,
    jmuser_pw VARCHAR2(50) NOT NULL,
    jmuser_name VARCHAR2(20) NOT NULL,
    jmuser_nickname VARCHAR2(20),
    jmuser_birth VARCHAR2(20),
    jmuser_gender VARCHAR2(5),
    jmuser_tel VARCHAR2(30),
    jmuser_email VARCHAR2(50),
    jmuser_addr VARCHAR2(100),
    jmuser_favorite VARCHAR2(100)
);
CREATE SEQUENCE jmuser_seq;

DROP TABLE jmuser;
DROP SEQUENCE jmuser_seq;

INSERT INTO jmuser VALUES
    (jmuser_seq.nextval,
    'admin',
    '1234',
    '�达',
    '������',
    '251212',
    '��',
    '000-1111-2222',
    'abc@gmail.com',
    '����',
    NULL);
commit;
TRUNCATE TABLE jmuser;

desc jmuser;
SELECT * FROM jmuser;
SELECT count(*) FROM jmuser WHERE jmuser_id='admin';